# Kotlin / Compose 基本保留
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**

# 本工程反射使用极少，保留 ViewModel 与解析相关
-keep class com.fs20mod.converter.** { *; }
-keepclassmembers class * extends androidx.lifecycle.ViewModel { <methods>; }

# XML 解析器
-keep class org.w3c.dom.** { *; }
-keep class org.xml.sax.** { *; }
-dontwarn javax.xml.**
