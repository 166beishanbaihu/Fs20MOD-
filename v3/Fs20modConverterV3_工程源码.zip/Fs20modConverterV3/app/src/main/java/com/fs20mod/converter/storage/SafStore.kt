package com.fs20mod.converter.storage

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File

/** SAF（存储访问框架）读写封装。 */
class SafStore(private val context: Context) {

    fun tree(uri: Uri): DocumentFile? = DocumentFile.fromTreeUri(context, uri)

    fun file(uri: Uri): DocumentFile? = DocumentFile.fromSingleUri(context, uri)

    /** 把 SAF 目录整棵复制到本地，返回文件数。 */
    fun copyTree(tree: DocumentFile, dest: File): Int {
        var count = 0
        fun walk(dir: DocumentFile, local: File) {
            local.mkdirs()
            dir.listFiles().forEach { child ->
                val name = child.name ?: return@forEach
                if (child.isDirectory) {
                    walk(child, File(local, name))
                } else if (copyFile(child, File(local, name))) {
                    count++
                }
            }
        }
        walk(tree, dest)
        return count
    }

    fun copyFile(source: DocumentFile, target: File): Boolean = runCatching {
        target.parentFile?.mkdirs()
        context.contentResolver.openInputStream(source.uri)?.use { input ->
            target.outputStream().use { input.copyTo(it) }
        }
        target.exists()
    }.getOrDefault(false)

    /** 把一个本地文件写入用户选定的目录。 */
    fun writeInto(dir: DocumentFile, file: File, mime: String = "application/zip"): Boolean = runCatching {
        val name = file.name
        dir.findFile(name)?.delete()
        val target = dir.createFile(mime, name) ?: return false
        context.contentResolver.openOutputStream(target.uri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        true
    }.getOrDefault(false)

    fun readText(file: DocumentFile): String? = runCatching {
        context.contentResolver.openInputStream(file.uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
    }.getOrNull()

    fun writeText(file: DocumentFile, text: String): Boolean = runCatching {
        context.contentResolver.openOutputStream(file.uri, "wt")?.use { it.write(text.toByteArray()) }
        true
    }.getOrDefault(false)
}
