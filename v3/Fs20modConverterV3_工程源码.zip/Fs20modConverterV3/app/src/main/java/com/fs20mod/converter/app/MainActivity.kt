package com.fs20mod.converter.app

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebSettings
import android.widget.FrameLayout
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.fs20mod.converter.web.AssetServer
import com.fs20mod.converter.web.WebBridge

class MainActivity : ComponentActivity(), WebBridge.Host {

    private lateinit var webView: WebView
    private lateinit var server: AssetServer
    private lateinit var bridge: WebBridge

    private var pendingAction: Pending = Pending.NONE

    private enum class Pending { NONE, FOLDER, ARCHIVE, EXPORT }

    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data ?: return@registerForActivityResult
        when (pendingAction) {
            Pending.FOLDER -> bridge.onFolderPicked(uri)
            Pending.ARCHIVE -> bridge.onArchivePicked(uri)
            Pending.EXPORT -> bridge.onExportPicked(uri)
            Pending.NONE -> Unit
        }
        pendingAction = Pending.NONE
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        server = AssetServer(this)
        val port = server.start()

        webView = WebView(this).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                cacheMode = WebSettings.LOAD_NO_CACHE
                loadWithOverviewMode = true
                useWideViewPort = false
                textZoom = 100
            }
            setBackgroundColor(android.graphics.Color.parseColor("#0E1211"))
            webViewClient = WebViewClient()
        }
        // 内容避开状态栏 / 导航栏 / 挖孔区域：用一个容器承载 WebView，由容器接收 inset
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0xFF0E1211.toInt()))
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        val root = FrameLayout(this).apply {
            setBackgroundColor(0xFF0E1211.toInt())
        }
        root.addView(
            webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        bridge = WebBridge(this, webView, this)
        webView.addJavascriptInterface(bridge, "bridge")
        webView.loadUrl("http://127.0.0.1:$port/")
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }
        ViewCompat.requestApplyInsets(root)
        setupBackHandling()
    }

    override fun onDestroy() {
        server.stop()
        runCatching { webView.destroy() }
        super.onDestroy()
    }

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this) {
            webView.evaluateJavascript("window.App && window.App.handleBack && window.App.handleBack()") { handled ->
                val back = handled?.trim()?.trim('"')
                if (back != "true") {
                    finish()
                }
            }
        }
    }

    override fun requestFolder() {
        pendingAction = Pending.FOLDER
        picker.launch(
            Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        )
    }

    override fun requestArchive() {
        pendingAction = Pending.ARCHIVE
        picker.launch(
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/zip"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        )
    }

    override fun requestExport() {
        pendingAction = Pending.EXPORT
        picker.launch(
            Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }
        )
    }

    override fun openExternal(url: String) {
        runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }
}
