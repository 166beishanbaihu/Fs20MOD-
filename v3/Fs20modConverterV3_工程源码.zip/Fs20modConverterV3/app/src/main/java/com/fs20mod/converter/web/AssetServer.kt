package com.fs20mod.converter.web

import android.content.Context
import java.io.BufferedOutputStream
import java.io.File
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/**
 * 本地 HTTP 服务：把 assets/ui 下的页面以 http://127.0.0.1:port 提供，
 * 让界面跑在真正的 http 协议下（WebView 直接加载）。
 */
class AssetServer(private val context: Context) {

    private var socket: ServerSocket? = null

    @Volatile
    private var running = false

    var port: Int = 0
        private set

    fun start(): Int {
        if (running) return port
        val server = ServerSocket(0, 20, InetAddress.getByName("127.0.0.1"))
        socket = server
        port = server.localPort
        running = true
        thread(name = "asset-http", isDaemon = true) {
            while (running) {
                val client = runCatching { server.accept() }.getOrNull() ?: break
                thread(isDaemon = true) { runCatching { serve(client) } }
            }
        }
        return port
    }

    fun stop() {
        running = false
        runCatching { socket?.close() }
        socket = null
    }

    private fun serve(client: Socket) {
        client.use { s ->
            val input = s.getInputStream().bufferedReader()
            val requestLine = input.readLine() ?: return
            val rawPath = requestLine.split(' ').getOrNull(1).orEmpty()
            val path = rawPath.substringBefore('?').removePrefix("/").ifBlank { "index.html" }
            val safePath = path.replace("..", "")

            val bytes = readAsset(safePath)
            val out = BufferedOutputStream(s.getOutputStream())
            if (bytes == null) {
                val body = "404 Not Found: $safePath".toByteArray()
                out.write("HTTP/1.1 404 Not Found\r\nContent-Type: text/plain; charset=utf-8\r\n".toByteArray())
                out.write("Content-Length: ${body.size}\r\nConnection: close\r\n\r\n".toByteArray())
                out.write(body)
            } else {
                out.write("HTTP/1.1 200 OK\r\n".toByteArray())
                out.write("Content-Type: ${mimeOf(safePath)}\r\n".toByteArray())
                out.write("Cache-Control: no-store\r\n".toByteArray())
                out.write("Content-Length: ${bytes.size}\r\nConnection: close\r\n\r\n".toByteArray())
                out.write(bytes)
            }
            out.flush()
        }
    }

    private fun readAsset(path: String): ByteArray? = runCatching {
        context.assets.open("ui/$path").use { it.readBytes() }
    }.getOrNull()

    private fun mimeOf(path: String): String = when {
        path.endsWith(".css") -> "text/css; charset=utf-8"
        path.endsWith(".js") -> "application/javascript; charset=utf-8"
        path.endsWith(".json") -> "application/json; charset=utf-8"
        path.endsWith(".svg") -> "image/svg+xml"
        path.endsWith(".png") -> "image/png"
        path.endsWith(".jpg") || path.endsWith(".jpeg") -> "image/jpeg"
        path.endsWith(".woff2") -> "font/woff2"
        else -> "text/html; charset=utf-8"
    }
}
