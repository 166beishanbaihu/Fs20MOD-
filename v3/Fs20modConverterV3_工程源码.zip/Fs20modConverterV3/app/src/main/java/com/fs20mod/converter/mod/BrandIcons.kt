package com.fs20mod.converter.mod

import android.content.Context
import android.util.Base64

/**
 * 品牌图标库：assets/brands/brand_<id>.png
 * 命名大小写混用（如 brand_thunderCreek.png），因此统一按小写比较。
 */
object BrandIcons {

    private var index: Map<String, String>? = null

    private fun index(context: Context): Map<String, String> {
        index?.let { return it }
        val built = runCatching {
            context.assets.list("brands")
                ?.filter { it.startsWith("brand_", true) && it.endsWith(".png", true) }
                ?.associate { name ->
                    // brand_lizard.png -> lizard
                    name.removePrefix("brand_").removePrefix("BRAND_")
                        .substringBeforeLast('.')
                        .lowercase() to "brands/$name"
                }
                .orEmpty()
        }.getOrDefault(emptyMap())
        index = built
        return built
    }

    /** 按品牌 ID 找图标资源路径（不区分大小写）。 */
    fun find(context: Context, brand: String): String? {
        val id = normalize(brand)
        if (id.isEmpty()) return null
        return index(context)[id]
    }

    /** 直接返回 data URL，供界面展示。 */
    fun dataUrl(context: Context, brand: String): String? {
        val path = find(context, brand) ?: return null
        return runCatching {
            val bytes = context.assets.open(path).use { it.readBytes() }
            "data:image/png;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
        }.getOrNull()
    }

    /** LIZARD / lizard / Lizard 统一为 lizard；去除可能的空格与下划线前缀。 */
    private fun normalize(brand: String): String =
        brand.trim().lowercase().removePrefix("brand_").replace(" ", "")
}
