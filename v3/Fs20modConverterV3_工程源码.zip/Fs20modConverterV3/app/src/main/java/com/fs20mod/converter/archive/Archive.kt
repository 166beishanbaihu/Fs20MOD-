package com.fs20mod.converter.archive

import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** zip 拆包与打包。 */
object Archive {

    fun unpack(zip: File, dest: File): Int {
        dest.mkdirs()
        var count = 0
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val name = entry.name.replace('\\', '/')
                if (!name.contains("..")) {
                    val out = File(dest, name)
                    if (entry.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zis.copyTo(it) }
                        count++
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return count
    }

    fun pack(source: File, target: File, onTick: (Int) -> Unit = {}): Boolean = runCatching {
        target.parentFile?.mkdirs()
        var n = 0
        ZipOutputStream(target.outputStream().buffered()).use { zos ->
            source.walkTopDown()
                .filter { it.isFile && !it.name.endsWith(".bak") }
                .sortedBy { it.relativeTo(source).path }
                .forEach { f ->
                    val rel = f.relativeTo(source).path.replace('\\', '/')
                    zos.putNextEntry(ZipEntry(rel))
                    f.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                    onTick(++n)
                }
        }
        true
    }.getOrDefault(false)

    /** zip 内如果是“一个文件夹包一个 mod”，下钻到真正的 mod 根。 */
    fun modRoot(dir: File): File {
        val children = dir.listFiles()?.filter { !it.name.startsWith(".") }.orEmpty()
        if (children.size == 1 && children[0].isDirectory) {
            val inner = children[0]
            if (inner.walkTopDown().any { it.isFile && it.name.equals("modDesc.xml", true) }) {
                return inner
            }
        }
        return dir
    }
}
