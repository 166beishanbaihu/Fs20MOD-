package com.fs20mod.converter.app

import android.app.Application
import com.fs20mod.converter.debug.RunLog

class ConverterApp : Application() {
    override fun onCreate() {
        super.onCreate()
        RunLog.init(this)
        RunLog.installCrashHandler(this)
    }
}
