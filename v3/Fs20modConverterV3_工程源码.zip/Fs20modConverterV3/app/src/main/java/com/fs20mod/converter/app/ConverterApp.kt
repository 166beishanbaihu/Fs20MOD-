package com.fs20mod.converter.app

import android.app.Application

class ConverterApp : Application()
