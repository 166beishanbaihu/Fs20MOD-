package com.fs20mod.converter.debug

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * 运行轨迹日志 + 崩溃采集。
 *
 * 设计要点沿用旧版 CrashLogger：任何未捕获异常都会落盘，并照常交给系统处理器终止进程。
 * 在此基础上增加"运行到哪一步"的轨迹记录：
 *  - 每条日志带毫秒时间戳、线程名、级别、TAG；
 *  - 内存环形缓冲供界面读取最近若干行；
 *  - 文件写入 filesDir/run_log.txt（超过 1MB 自动裁半）；
 *  - 崩溃时把最近 200 条轨迹连同堆栈一起写入私有目录与下载目录。
 */
object RunLog {

    private const val FILE_NAME = "run_log.txt"
    private const val CRASH_NAME = "crash_log.txt"
    private const val MAX_BYTES = 1_000_000L
    private const val RING_CAPACITY = 400
    private const val CRASH_TAIL = 200

    private val timeFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
    private val ring = ArrayDeque<String>()
    private val lock = Any()

    @Volatile
    private var dir: File? = null

    @Volatile
    private var sessionId: String = ""

    fun init(context: Context) {
        dir = context.applicationContext.filesDir
        sessionId = SimpleDateFormat("MMdd-HHmmss", Locale.US).format(Date())
        i("APP", "进程启动 pid=${android.os.Process.myPid()} 会话=$sessionId")
        i(
            "APP",
            "设备 ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        )
    }

    // ---- 写日志 ----

    fun i(tag: String, msg: String) = write("I", tag, msg, null)

    fun w(tag: String, msg: String) = write("W", tag, msg, null)

    fun e(tag: String, msg: String, tr: Throwable? = null) = write("E", tag, msg, tr)

    /** 流程节点：统一用 STEP 级别，方便崩溃报告里看出卡在哪一步。 */
    fun step(tag: String, msg: String) = write("S", tag, msg, null)

    private fun write(level: String, tag: String, msg: String, tr: Throwable?) {
        val stamp = synchronized(timeFmt) { timeFmt.format(Date()) }
        val head = "$stamp ${level}/${Thread.currentThread().name} [$tag] $msg"
        val body = if (tr != null) {
            head + "\n" + stackOf(tr)
        } else {
            head
        }

        synchronized(lock) {
            while (ring.size >= RING_CAPACITY) ring.removeFirst()
            ring.addLast(body)
            val f = dir?.let { File(it, FILE_NAME) } ?: return
            runCatching { appendTo(f, body) }
        }
    }

    private fun appendTo(file: File, text: String) {
        if (file.length() > MAX_BYTES) {
            // 只保留后半段，避免日志无限增长
            val all = file.readText()
            file.writeText(all.substring(all.length / 2))
        }
        file.appendText(text + "\n")
    }

    private fun stackOf(tr: Throwable): String {
        val sw = StringWriter()
        tr.printStackTrace(PrintWriter(sw))
        return sw.toString().trimEnd()
    }

    // ---- 读取 ----

    fun tail(lines: Int = 120): String = synchronized(lock) {
        ring.toList().takeLast(lines).joinToString("\n")
    }

    fun file(context: Context): File = File(context.filesDir, FILE_NAME)

    fun lastCrash(context: Context): String? = runCatching {
        val f = File(context.filesDir, CRASH_NAME)
        if (f.exists()) f.readText() else null
    }.getOrNull()

    fun clearCrash(context: Context) {
        runCatching { File(context.filesDir, CRASH_NAME).delete() }
    }

    // ---- 崩溃采集 ----

    fun installCrashHandler(application: Application) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching {
                val report = buildCrashReport(thread, throwable)
                runCatching { File(application.filesDir, CRASH_NAME).writeText(report) }
                runCatching { writeToDownloads(application, report) }
            }
            // 保持系统原生崩溃行为：先落盘，再交给默认处理器
            previous?.uncaughtException(thread, throwable)
                ?: runCatching { android.os.Process.killProcess(android.os.Process.myPid()) }
        }
        i("CRASH", "未捕获异常处理器已安装")
    }

    private fun buildCrashReport(thread: Thread, throwable: Throwable): String {
        val ts = synchronized(timeFmt) { timeFmt.format(Date()) }
        return buildString {
            appendLine("=== Fs20modConverter 崩溃报告 ===")
            appendLine("时间: $ts  会话: $sessionId")
            appendLine("设备: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("线程: ${thread.name}")
            appendLine()
            appendLine("---- 崩溃堆栈 ----")
            appendLine(stackOf(throwable))
            var cause = throwable
            while (cause.cause != null) cause = cause.cause!!
            if (cause !== throwable) {
                appendLine()
                appendLine("---- 根因 ----")
                appendLine("${cause.javaClass.name}: ${cause.message}")
                appendLine(stackOf(cause))
            }
            appendLine()
            appendLine("---- 崩溃前运行轨迹（最后 $CRASH_TAIL 条）----")
            appendLine(tail(CRASH_TAIL))
        }
    }

    private fun writeToDownloads(a: Application, text: String) {
        val resolver = a.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "Fs20crash_${System.currentTimeMillis()}.txt")
            put(MediaStore.Downloads.MIME_TYPE, "text/plain")
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
        resolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
    }
}
