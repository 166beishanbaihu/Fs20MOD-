package com.fs20mod.converter.mod

import android.content.Context
import com.fs20mod.converter.debug.RunLog
import com.fs20mod.converter.storage.LocalFs
import com.fs20mod.converter.storage.ModFs
import com.fs20mod.converter.tools.ImageThumb
import java.io.File

/** modDesc 中 descVersion 对应的游戏判定；留好扩展点。 */
object GameVersions {
    private val table = listOf(
        40..59 to "FS19",
    )

    /** 后续可按需加入 FS22 / FS25 区间。 */
    fun labelOf(descVersion: Int?): String {
        if (descVersion == null) return "未知"
        table.forEach { (range, label) ->
            if (descVersion in range) return label
        }
        return "未知（descVersion=$descVersion）"
    }
}

data class VehicleInfo(
    val xmlName: String,
    val type: String,
    val imageRef: String?,
    val imageUrl: String?,
    val price: String,
    val brand: String,
    val brandLogoUrl: String?,
    val i3dRef: String?,
    val i3dExists: Boolean,
    val ddsRefs: Int,
    val skippedRefs: Int,
)

data class ModInfo(
    val rootName: String,
    val descVersion: String,
    val gameLabel: String,
    val modVersion: String,
    val title: String,
    val vehicles: List<VehicleInfo>,
)

/** 读取 mod 结构：所有读取都走 ModFs，本地目录与 SAF 原文件夹一视同仁。 */
object ModReader {

    private val descVersionRe = Regex("""descVersion\s*=\s*"([^"]*)"""")
    private val versionRe = Regex("""<version>([^<]*)</version>""")
    private val titleRe = Regex("""<title>\s*<en>([^<]*)</en>""")
    private val storeItemRe = Regex("""<storeItem\b[^>]*?xmlFilename\s*=\s*"([^"]+)"""")
    private val typeRe = Regex("""<vehicle\b[^>]*?\btype\s*=\s*"([^"]*)"""")
    private val imageRe = Regex("""<image>([^<]*)</image>""")
    private val priceRe = Regex("""<price>([^<]*)</price>""")
    private val brandRe = Regex("""<brand>([^<]*)</brand>""")
    private val filenameRe = Regex("""<filename>([^<]*)</filename>""")

    fun inspect(context: Context, root: File): ModInfo? = inspect(context, LocalFs(root))

    fun inspect(context: Context, fs: ModFs): ModInfo? {
        RunLog.step("READER", "开始解析 ${fs.label}")
        val modDescPath = findModDesc(fs) ?: run {
            RunLog.w("READER", "未找到 modDesc.xml")
            return null
        }
        RunLog.step("READER", "modDesc=$modDescPath")

        val text = fs.readText(modDescPath) ?: return null

        val descVersion = descVersionRe.find(text)?.groupValues?.get(1)?.trim()
        val gameLabel = GameVersions.labelOf(descVersion?.toIntOrNull())
        RunLog.step("READER", "descVersion=$descVersion → $gameLabel")

        val modVersion = versionRe.find(text)?.groupValues?.get(1)?.trim().orEmpty()
        val title = titleRe.find(text)?.groupValues?.get(1)?.trim().orEmpty()
        RunLog.step("READER", "MOD 版本=$modVersion 标题=$title")

        val refs = storeItemRe.findAll(text).map { it.groupValues[1].trim() }.distinct().toList()
        RunLog.step("READER", "storeItem 共 ${refs.size} 条（去重后）")

        val vehicles = refs.map { ref ->
            val vehiclePath = locate(fs, ref)
            RunLog.step("READER", "storeItem xmlFilename=$ref → ${vehiclePath ?: "未找到"}")
            inspectVehicle(context, fs, ref, vehiclePath)
        }

        return ModInfo(
            rootName = fs.label,
            descVersion = descVersion.orEmpty(),
            gameLabel = gameLabel,
            modVersion = modVersion,
            title = title,
            vehicles = vehicles,
        )
    }

    /** .xml 后缀大小写不敏感，前缀必须精确匹配；同目录优先，最后才按文件名兜底。 */
    fun locate(fs: ModFs, ref: String, from: String? = null): String? {
        val normalized = ref.replace('\\', '/').removePrefix("./")
        val all = fs.list()

        all.firstOrNull { it == normalized }?.let { return it }

        val target = normalized.substringAfterLast('/')
        val parentHint = from?.substringBeforeLast('/', "")?.takeIf { it.isNotEmpty() }
        val prefix = normalized.substringBeforeLast('/', "")

        if (parentHint != null) {
            all.firstOrNull {
                it.substringBeforeLast('/', "") == parentHint &&
                    it.substringAfterLast('/').equals(target, true)
            }?.let { return it }
        }
        if (prefix.isNotEmpty()) {
            all.firstOrNull {
                it.substringBeforeLast('/', "").equals(prefix, true) &&
                    it.substringAfterLast('/').equals(target, true)
            }?.let { return it }
        }
        return all.firstOrNull { it.substringAfterLast('/').equals(target, true) }
    }

    private fun inspectVehicle(
        context: Context,
        fs: ModFs,
        ref: String,
        path: String?,
    ): VehicleInfo {
        if (path == null) {
            RunLog.w("READER", "车辆文件缺失：$ref")
            return VehicleInfo(ref, "", null, null, "", "", null, null, false, 0, 0)
        }
        val text = fs.readText(path).orEmpty()

        val type = typeRe.find(text)?.groupValues?.get(1).orEmpty()
        val imageRef = imageRe.find(text)?.groupValues?.get(1)?.trim()
        val price = priceRe.find(text)?.groupValues?.get(1)?.trim().orEmpty()
        val brand = brandRe.find(text)?.groupValues?.get(1)?.trim().orEmpty()
        val i3dRef = filenameRe.find(text)?.groupValues?.get(1)?.trim()

        RunLog.step("READER", "车辆 $path: type=$type brand=$brand price=$price image=$imageRef i3d=$i3dRef")

        val imageUrl = imageRef?.let { image ->
            locate(fs, image, from = path)?.let { ImageThumb.dataUrl(fs, it, 420) }
        }
        val logoUrl = brand.takeIf { it.isNotBlank() }?.let { findBrandLogo(context, fs, it) }

        val i3dPath = i3dRef?.let { locate(fs, it, from = path) }
        val i3dCheck = i3dPath?.let { analyseI3d(fs, it) } ?: I3dCheck(0, 0, false)

        return VehicleInfo(
            xmlName = ref,
            type = type,
            imageRef = imageRef,
            imageUrl = imageUrl,
            price = price,
            brand = brand,
            brandLogoUrl = logoUrl,
            i3dRef = i3dRef,
            i3dExists = i3dCheck.exists,
            ddsRefs = i3dCheck.ddsRefs,
            skippedRefs = i3dCheck.skippedRefs,
        )
    }

    data class I3dCheck(val ddsRefs: Int, val skippedRefs: Int, val exists: Boolean = true)

    /** 统计 i3d 内 .dds 引用，以及以 $ 开头被跳过的行。 */
    fun analyseI3d(fs: ModFs, path: String): I3dCheck {
        val text = fs.readText(path, Charsets.ISO_8859_1) ?: return I3dCheck(0, 0, false)
        var dds = 0
        var skipped = 0
        val blocks = Regex("""<Files>([\s\S]*?)</Files>""").findAll(text)
        blocks.forEach { block ->
            Regex("""filename\s*=\s*"([^"]*)"""").findAll(block.groupValues[1]).forEach { m ->
                val v = m.groupValues[1].trim()
                if (v.startsWith("$")) {
                    skipped++
                } else if (v.endsWith(".dds", true)) {
                    dds++
                }
            }
        }
        return I3dCheck(dds, skipped, true)
    }

    /**
     * 品牌图标：优先用内置品牌包（assets/brands/brand_<id>.png，不区分大小写），
     * 内置包没有时再回落到 mod 自带图标。
     */
    private fun findBrandLogo(context: Context, fs: ModFs, brand: String): String? {
        BrandIcons.dataUrl(context, brand)?.let { return it }

        val id = brand.lowercase().removePrefix("brand_").replace(" ", "")
        val candidate = fs.list().firstOrNull { path ->
            val ext = path.substringAfterLast('.', "").lowercase()
            if (ext !in setOf("png", "jpg", "jpeg", "dds")) return@firstOrNull false
            val name = path.substringAfterLast('/').substringBeforeLast('.').lowercase()
            name == "brand_$id" || name == id || name.endsWith("_$id")
        } ?: return null

        return ImageThumb.dataUrl(fs, candidate, 160)
    }

    private fun findModDesc(fs: ModFs): String? =
        fs.list().firstOrNull { it.substringAfterLast('/').equals("modDesc.xml", true) }
}
