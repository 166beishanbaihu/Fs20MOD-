package com.fs20mod.converter.mod

import android.content.Context
import com.fs20mod.converter.codec.DdsCodec
import java.io.File
import java.util.Base64

/** modDesc 中 descVersion 对应的游戏判定；留好扩展点。 */
object GameVersions {
    private val table = listOf(
        40..59 to "FS19",
    )

    /** 后续可按需加入 FS22 / FS25 区间。 */
    fun labelOf(descVersion: Int?): String {
        if (descVersion == null) return "未知"
        table.forEach { (range, label) ->
            if (descVersion in range) return label
        }
        return "未知（descVersion=$descVersion）"
    }
}

data class VehicleInfo(
    val xmlName: String,
    val type: String,
    val imageRef: String?,
    val imageUrl: String?,
    val price: String,
    val brand: String,
    val brandLogoUrl: String?,
    val i3dRef: String?,
    val i3dExists: Boolean,
    val ddsRefs: Int,
    val skippedRefs: Int,
)

data class ModInfo(
    val rootName: String,
    val descVersion: String,
    val gameLabel: String,
    val modVersion: String,
    val title: String,
    val vehicles: List<VehicleInfo>,
)

/** 读取 mod 结构，供界面展示与转换使用。 */
object ModReader {

    private val descVersionRe = Regex("""descVersion\s*=\s*"([^"]*)"""")
    private val versionRe = Regex("""<version>([^<]*)</version>""")
    private val titleRe = Regex("""<title>\s*<en>([^<]*)</en>""")
    private val storeItemRe = Regex("""<storeItem\b[^>]*?xmlFilename\s*=\s*"([^"]+)"""")
    private val typeRe = Regex("""<vehicle\b[^>]*?\btype\s*=\s*"([^"]*)"""")
    private val imageRe = Regex("""<image>([^<]*)</image>""")
    private val priceRe = Regex("""<price>([^<]*)</price>""")
    private val brandRe = Regex("""<brand>([^<]*)</brand>""")
    private val filenameRe = Regex("""<filename>([^<]*)</filename>""")

    fun inspect(context: Context, root: File): ModInfo? {
        val modDesc = findModDesc(root) ?: return null
        val text = runCatching { modDesc.readText(Charsets.UTF_8) }.getOrNull() ?: return null

        val descVersion = descVersionRe.find(text)?.groupValues?.get(1)?.trim()
        val gameLabel = GameVersions.labelOf(descVersion?.toIntOrNull())
        val modVersion = versionRe.find(text)?.groupValues?.get(1)?.trim().orEmpty()
        val title = titleRe.find(text)?.groupValues?.get(1)?.trim().orEmpty()

        val vehicles = storeItemRe.findAll(text).map { m ->
            val ref = m.groupValues[1].trim()
            val vehicleFile = locate(root, ref)
            inspectVehicle(context, root, ref, vehicleFile)
        }.toList()

        return ModInfo(
            rootName = root.name,
            descVersion = descVersion.orEmpty(),
            gameLabel = gameLabel,
            modVersion = modVersion,
            title = title,
            vehicles = vehicles,
        )
    }

    /** .xml 后缀大小写不敏感，前缀必须精确匹配。 */
    private fun locate(root: File, ref: String): File? {
        val normalized = ref.replace('\\', '/')
        val direct = File(root, normalized)
        if (direct.isFile) return direct

        val target = normalized.substringAfterLast('/')
        val prefix = normalized.substringBeforeLast('/', "")
        if (prefix.isEmpty()) {
            return root.walkTopDown().firstOrNull { it.isFile && it.name.equals(target, true) }
        }
        // 保留路径前缀，仅在文件名后缀上做大小写容错
        val folder = File(root, prefix)
        val base = target.substringBeforeLast('.')
        val ext = target.substringAfterLast('.', "xml")
        return folder.listFiles()?.firstOrNull {
            it.isFile && it.nameWithoutExtension.equals(base, true) && it.extension.equals(ext, true)
        }
    }

    private fun inspectVehicle(context: Context, root: File, ref: String, file: File?): VehicleInfo {
        if (file == null || !file.exists()) {
            return VehicleInfo(ref, "", null, null, "", "", null, null, false, 0, 0)
        }
        val text = runCatching { file.readText(Charsets.UTF_8) }.getOrElse { "" }

        val type = typeRe.find(text)?.groupValues?.get(1).orEmpty()
        val imageRef = imageRe.find(text)?.groupValues?.get(1)?.trim()
        val price = priceRe.find(text)?.groupValues?.get(1)?.trim().orEmpty()
        val brand = brandRe.find(text)?.groupValues?.get(1)?.trim().orEmpty()
        val i3dRef = filenameRe.find(text)?.groupValues?.get(1)?.trim()

        val imageUrl = imageRef?.let { resolveImage(root, file, it) }
        val logoUrl = brand.takeIf { it.isNotBlank() }?.let { findBrandLogo(context, root, it) }

        val i3dFile = i3dRef?.let { resolveSibling(root, file, it) }
        val i3dCheck = i3dFile?.takeIf { it.isFile }?.let { analyseI3d(it) } ?: I3dCheck(0, 0)

        return VehicleInfo(
            xmlName = ref,
            type = type,
            imageRef = imageRef,
            imageUrl = imageUrl,
            price = price,
            brand = brand,
            brandLogoUrl = logoUrl,
            i3dRef = i3dRef,
            i3dExists = i3dCheck.exists,
            ddsRefs = i3dCheck.ddsRefs,
            skippedRefs = i3dCheck.skippedRefs,
        )
    }

    data class I3dCheck(val ddsRefs: Int, val skippedRefs: Int, val exists: Boolean = true)

    /** 统计 i3d 内 .dds 引用，以及以 $ 开头被跳过的行。 */
    fun analyseI3d(i3d: File): I3dCheck {
        val text = runCatching { i3d.readText(Charsets.ISO_8859_1) }.getOrNull()
            ?: return I3dCheck(0, 0, false)
        var dds = 0
        var skipped = 0
        val blocks = Regex("""<Files>([\s\S]*?)</Files>""").findAll(text)
        blocks.forEach { block ->
            Regex("""filename\s*=\s*"([^"]*)"""").findAll(block.groupValues[1]).forEach { m ->
                val v = m.groupValues[1].trim()
                if (v.startsWith("$")) {
                    skipped++
                } else if (v.endsWith(".dds", true)) {
                    dds++
                }
            }
        }
        return I3dCheck(dds, skipped, true)
    }

    private fun resolveImage(root: File, vehicleFile: File, ref: String): String? {
        val file = resolveSibling(root, vehicleFile, ref) ?: return null
        return when (file.extension.lowercase()) {
            "dds" -> DdsCodec.toDataUrl(file)
            "png", "jpg", "jpeg" -> runCatching {
                "data:image/${if (file.extension.equals("png", true)) "png" else "jpeg"};base64," +
                    Base64.getEncoder().encodeToString(file.readBytes())
            }.getOrNull()
            else -> null
        }
    }

    private fun resolveSibling(root: File, from: File, ref: String): File? {
        val normalized = ref.replace('\\', '/')
        val abs = File(root, normalized)
        if (abs.isFile) return abs
        val local = File(from.parentFile, normalized)
        if (local.isFile) return local
        val name = normalized.substringAfterLast('/')
        return root.walkTopDown().firstOrNull { it.isFile && it.name.equals(name, true) }
    }

    /**
     * 品牌图标：优先用内置品牌包（assets/brands/brand_<id>.png，不区分大小写），
     * 内置包没有时再回落到 mod 自带图标。
     */
    private fun findBrandLogo(context: Context, root: File, brand: String): String? {
        BrandIcons.dataUrl(context, brand)?.let { return it }

        val id = brand.lowercase().removePrefix("brand_").replace(" ", "")
        val local = root.walkTopDown()
            .filter { it.isFile && it.extension.lowercase() in setOf("png", "jpg", "jpeg", "dds") }
            .firstOrNull { f ->
                val n = f.nameWithoutExtension.lowercase()
                n == "brand_$id" || n == id || n.endsWith("_$id")
            } ?: return null

        return when (local.extension.lowercase()) {
            "dds" -> DdsCodec.toDataUrl(local, 256)
            else -> runCatching {
                "data:image/${if (local.extension.equals("png", true)) "png" else "jpeg"};base64," +
                    Base64.getEncoder().encodeToString(local.readBytes())
            }.getOrNull()
        }
    }

    private fun findModDesc(root: File): File? =
        root.walkTopDown().firstOrNull { it.isFile && it.name.equals("modDesc.xml", true) }
}
