package com.fs20mod.converter.tools

/** 极简 JSON 序列化（只用于桥接回调）。 */
object Json {

    fun obj(vararg pairs: Pair<String, Any?>): String =
        pairs.joinToString(",", "{", "}") { (k, v) -> "\"${escape(k)}\":${value(v)}" }

    fun value(v: Any?): String = when (v) {
        null -> "null"
        is String -> "\"${escape(v)}\""
        is Boolean, is Int, is Long, is Double, is Float -> v.toString()
        is Map<*, *> -> {
            val entries = v.entries.joinToString(",") { (k, value) ->
                "\"${escape(k.toString())}\":${value(value)}"
            }
            "{$entries}"
        }
        is List<*> -> v.joinToString(",", "[", "]") { value(it) }
        else -> "\"${escape(v.toString())}\""
    }

    fun escape(s: String): String = buildString {
        s.forEach { c ->
            when (c) {
                '"' -> append("\\\"")
                '\\' -> append("\\\\")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> if (c.code < 0x20) append("\\u%04x".format(c.code)) else append(c)
            }
        }
    }
}
