package com.fs20mod.converter.codec

import android.graphics.Bitmap
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * DDS 解码：DXT1 / DXT3 / DXT5 与未压缩 24/32 位。
 * 只解码 mip0，用于贴图转换和界面预览。
 */
object DdsCodec {

    fun toPng(dds: File, png: File): Boolean = runCatching {
        val bitmap = decode(dds.readBytes()) ?: return false
        png.parentFile?.mkdirs()
        png.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        true
    }.getOrDefault(false)

    /** 直接给字节流：用于 SAF 就地读写（不落临时文件）。 */
    fun toPngBytes(data: ByteArray): ByteArray? = runCatching {
        val bitmap = decode(data) ?: return null
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        bitmap.recycle()
        out.toByteArray()
    }.getOrNull()

    /** 解码后转为 data URL，供 HTML 界面直接展示。 */
    fun toDataUrl(dds: File, maxSide: Int = 512): String? = runCatching {
        val bitmap = decode(dds.readBytes()) ?: return null
        val scaled = downscale(bitmap, maxSide)
        if (scaled !== bitmap) bitmap.recycle()
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.PNG, 90, out)
        scaled.recycle()
        "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }.getOrNull()

    fun toDataUrl(data: ByteArray, maxSide: Int = 512): String? = runCatching {
        val bitmap = decode(data) ?: return null
        val scaled = downscale(bitmap, maxSide)
        if (scaled !== bitmap) bitmap.recycle()
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.PNG, 90, out)
        scaled.recycle()
        "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }.getOrNull()

    fun decode(data: ByteArray): Bitmap? {
        if (data.size < 128 || readInt(data, 0) != 0x20534444) return null
        val height = readInt(data, 12)
        val width = readInt(data, 16)
        if (width !in 1..8192 || height !in 1..8192) return null

        val fourCc = String(data, 84, 4, Charsets.US_ASCII)
        val pixels = IntArray(width * height)

        when (fourCc) {
            "DXT1" -> decodeBlocks(data, 128, width, height, pixels, Fmt.DXT1)
            "DXT3" -> decodeBlocks(data, 128, width, height, pixels, Fmt.DXT3)
            "DXT5" -> decodeBlocks(data, 128, width, height, pixels, Fmt.DXT5)
            "DX10" -> decodeUncompressed(data, 148, width, height, pixels)
            else -> decodeUncompressed(data, 128, width, height, pixels)
        }
        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
    }

    private enum class Fmt { DXT1, DXT3, DXT5 }

    private fun decodeBlocks(
        data: ByteArray,
        start: Int,
        width: Int,
        height: Int,
        out: IntArray,
        fmt: Fmt,
    ) {
        val blockBytes = if (fmt == Fmt.DXT1) 8 else 16
        val cols = (width + 3) / 4
        val rows = (height + 3) / 4
        var offset = start

        repeat(rows) { by ->
            repeat(cols) { bx ->
                if (offset + blockBytes > data.size) return
                val alphas = IntArray(16) { 255 }

                if (fmt != Fmt.DXT1) {
                    if (fmt == Fmt.DXT3) {
                        repeat(8) { i ->
                            val v = data[offset + i].toInt() and 0xFF
                            alphas[i * 2] = (v and 0x0F) * 17
                            alphas[i * 2 + 1] = ((v shr 4) and 0x0F) * 17
                        }
                    } else {
                        val a0 = data[offset].toInt() and 0xFF
                        val a1 = data[offset + 1].toInt() and 0xFF
                        repeat(16) { i ->
                            alphas[i] = dxt5Alpha(readBits(data, offset + 2, i * 3, 3), a0, a1)
                        }
                    }
                    offset += 8
                }

                val c0 = readShort(data, offset)
                val c1 = readShort(data, offset + 2)
                val rgb0 = rgb565(c0)
                val rgb1 = rgb565(c1)
                val idx = readInt(data, offset + 4)

                val transparent = fmt == Fmt.DXT1 && c0 <= c1
                val palette = if (transparent) {
                    intArrayOf(rgb0, rgb1, mix(rgb0, rgb1, 1, 1))
                } else {
                    intArrayOf(rgb0, rgb1, mix(rgb0, rgb1, 2, 1), mix(rgb0, rgb1, 1, 2))
                }

                repeat(16) { i ->
                    val x = bx * 4 + (i % 4)
                    val y = by * 4 + (i / 4)
                    if (x < width && y < height) {
                        val sel = (idx shr (i * 2)) and 0x3
                        val a = if (transparent && sel == 3) 0 else alphas[i]
                        val rgb = if (transparent && sel == 3) 0 else palette[sel]
                        out[y * width + x] = (a shl 24) or (rgb and 0xFFFFFF)
                    }
                }
                offset += 8
            }
        }
    }

    /** 从 6 字节小端位流里取 n 位。 */
    private fun readBits(data: ByteArray, base: Int, bitOffset: Int, bitCount: Int): Int {
        var value = 0
        repeat(bitCount) { b ->
            val pos = bitOffset + b
            val byteIdx = base + pos / 8
            if (byteIdx >= data.size) return value
            val bit = (data[byteIdx].toInt() shr (pos % 8)) and 1
            value = value or (bit shl b)
        }
        return value
    }

    private fun dxt5Alpha(idx: Int, a0: Int, a1: Int): Int = when {
        idx == 0 -> a0
        idx == 1 -> a1
        a0 > a1 -> ((8 - idx) * a0 + (idx - 1) * a1) / 7
        idx <= 5 -> ((6 - idx) * a0 + (idx - 1) * a1) / 5
        idx == 6 -> 0
        else -> 255
    }

    private fun decodeUncompressed(
        data: ByteArray,
        start: Int,
        width: Int,
        height: Int,
        out: IntArray,
    ) {
        val bits = readInt(data, 88).coerceAtLeast(24)
        val step = if (bits == 24) 3 else 4
        val rMask = readInt(data, 92)
        val gMask = readInt(data, 96)
        val bMask = readInt(data, 100)
        val aMask = readInt(data, 104)

        var offset = start
        repeat(height) { y ->
            repeat(width) { x ->
                if (offset + step > data.size) return
                val v = (data[offset].toInt() and 0xFF) or
                    ((data[offset + 1].toInt() and 0xFF) shl 8) or
                    ((data[offset + 2].toInt() and 0xFF) shl 16) or
                    (if (step == 4) ((data[offset + 3].toInt() and 0xFF) shl 24) else (255 shl 24))
                val r = channel(v, rMask)
                val g = channel(v, gMask)
                val b = channel(v, bMask)
                val a = if (aMask != 0) channel(v, aMask) else 255
                out[y * width + x] = (a shl 24) or (r shl 16) or (g shl 8) or b
                offset += step
            }
        }
    }

    private fun channel(value: Int, mask: Int): Int {
        if (mask == 0) return 255
        var shift = 0
        var m = mask
        while (m and 1 == 0) {
            m = m ushr 1
            shift++
        }
        val bits = Integer.bitCount(mask)
        val raw = (value shr shift) and ((1 shl bits) - 1)
        return if (bits == 8) raw else raw * 255 / ((1 shl bits) - 1)
    }

    private fun rgb565(c: Int): Int {
        val r = ((c shr 11) and 0x1F) * 255 / 31
        val g = ((c shr 5) and 0x3F) * 255 / 63
        val b = (c and 0x1F) * 255 / 31
        return (r shl 16) or (g shl 8) or b
    }

    private fun mix(c1: Int, c2: Int, w1: Int, w2: Int): Int {
        val t = w1 + w2
        val r = (((c1 shr 16) and 0xFF) * w1 + ((c2 shr 16) and 0xFF) * w2) / t
        val g = (((c1 shr 8) and 0xFF) * w1 + ((c2 shr 8) and 0xFF) * w2) / t
        val b = (((c1 and 0xFF) * w1 + (c2 and 0xFF) * w2) / t)
        return (r shl 16) or (g shl 8) or b
    }

    private fun downscale(src: Bitmap, maxSide: Int): Bitmap {
        val longSide = maxOf(src.width, src.height)
        if (longSide <= maxSide) return src
        val ratio = maxSide.toFloat() / longSide
        return Bitmap.createScaledBitmap(
            src,
            (src.width * ratio).toInt().coerceAtLeast(1),
            (src.height * ratio).toInt().coerceAtLeast(1),
            true
        )
    }

    private fun readInt(data: ByteArray, at: Int): Int =
        (data[at].toInt() and 0xFF) or
            ((data[at + 1].toInt() and 0xFF) shl 8) or
            ((data[at + 2].toInt() and 0xFF) shl 16) or
            ((data[at + 3].toInt() and 0xFF) shl 24)

    private fun readShort(data: ByteArray, at: Int): Int =
        (data[at].toInt() and 0xFF) or ((data[at + 1].toInt() and 0xFF) shl 8)
}
