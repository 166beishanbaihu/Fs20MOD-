package com.fs20mod.converter.tools

import org.w3c.dom.Document
import java.io.File
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

/** DOM 解析与写回（容错优先）。 */
object XmlKit {

    fun parse(file: File): Document? = runCatching {
        val factory = DocumentBuilderFactory.newInstance()
        runCatching { factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
        runCatching { factory.setFeature("http://xml.org/sax/features/external-general-entities", false) }
        runCatching { factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
        factory.newDocumentBuilder().parse(file)
    }.getOrNull()

    fun parseText(text: String): Document? = runCatching {
        val factory = DocumentBuilderFactory.newInstance()
        runCatching { factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
        runCatching { factory.setFeature("http://xml.org/sax/features/external-general-entities", false) }
        runCatching { factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
        factory.newDocumentBuilder().parse(text.byteInputStream(Charsets.UTF_8))
    }.getOrNull()

    fun toText(doc: Document): String? = runCatching {
        val out = java.io.StringWriter()
        TransformerFactory.newInstance().newTransformer().apply {
            setOutputProperty(OutputKeys.ENCODING, "UTF-8")
            setOutputProperty(OutputKeys.INDENT, "yes")
        }.transform(DOMSource(doc), StreamResult(out))
        out.toString()
    }.getOrNull()

    fun write(doc: Document, file: File): Boolean = runCatching {
        TransformerFactory.newInstance().newTransformer().apply {
            setOutputProperty(OutputKeys.ENCODING, "UTF-8")
            setOutputProperty(OutputKeys.INDENT, "yes")
        }.transform(DOMSource(doc), StreamResult(file))
        true
    }.getOrDefault(false)

    /** 逐行替换文本，跳过以 $ 开头的资源引用行。 */
    fun replaceTextLines(file: File, transform: (String) -> String): Int {
        val text = runCatching { file.readText(Charsets.ISO_8859_1) }.getOrNull() ?: return 0
        var changed = 0
        val out = text.lineSequence().joinToString("\n") { line ->
            val transformed = transform(line)
            if (transformed != line) changed++
            transformed
        }
        if (changed > 0) file.writeText(out, Charsets.ISO_8859_1)
        return changed
    }
}
