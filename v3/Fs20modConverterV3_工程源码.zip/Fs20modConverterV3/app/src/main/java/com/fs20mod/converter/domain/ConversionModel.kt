package com.fs20mod.converter.domain

/** 转换开关集合。 */
data class ConvertConfig(
    val ddsToPng: Boolean = true,
    val renameVehicles: Boolean = true,
    val rewriteTitle: Boolean = true,
    val syncI3d: Boolean = true,
    val keepOriginals: Boolean = false,
    val outputName: String = "",
)

/** 管线阶段。 */
enum class Phase(val title: String) {
    PREPARE("准备文件"),
    TEXTURE("贴图转换"),
    STORE_ITEMS("商店条目处理"),
    I3D("I3D 同步"),
    ARCHIVE("打包输出"),
    FINISHED("完成"),
}

enum class Level { INFO, WARN, ERROR }

data class LogEntry(val time: String, val level: Level, val message: String)

data class Progress(
    val phase: Phase = Phase.PREPARE,
    val ratio: Float = 0f,
    val note: String = "",
    val running: Boolean = false,
)

/** 单个阶段的统计。 */
data class PassReport(
    val label: String,
    val details: Map<String, String> = emptyMap(),
    val warnings: List<String> = emptyList(),
)

/** 一次转换的整体结果。 */
data class ConversionReport(
    val succeeded: Boolean,
    val zipPath: String? = null,
    val archiveName: String = "",
    val message: String = "",
    val details: Map<String, String> = emptyMap(),
    val warnings: List<String> = emptyList(),
)

/** 输入来源。 */
enum class SourceKind { FOLDER, ARCHIVE }

data class SourceRef(val kind: SourceKind, val uri: String, val label: String)
