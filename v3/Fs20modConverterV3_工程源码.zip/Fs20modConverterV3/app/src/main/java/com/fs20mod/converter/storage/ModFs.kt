package com.fs20mod.converter.storage

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.nio.charset.Charset

/**
 * mod 文件系统抽象。
 *
 * 存在的意义：让同一套转换逻辑既能跑在本地解压目录（压缩包模式），
 * 也能直接跑在 SAF 授权的原文件夹上（文件夹模式，不复制、就地覆盖）。
 * 所有路径都是相对 mod 根目录、以 / 分隔的字符串。
 */
interface ModFs {

    val label: String

    /** 全部文件的相对路径。 */
    fun list(): List<String>

    fun exists(path: String): Boolean

    fun readText(path: String, charset: Charset = Charsets.UTF_8): String?

    fun writeText(path: String, text: String, charset: Charset = Charsets.UTF_8): Boolean

    fun read(path: String): ByteArray?

    fun write(path: String, bytes: ByteArray, mime: String = "application/octet-stream"): Boolean

    fun delete(path: String): Boolean

    fun rename(from: String, to: String): Boolean

    /** 只有本地实现才有真实根目录（打包 zip 用）。 */
    fun localRoot(): File? = null
}

/** 本地目录实现（压缩包解压后 / 缓存目录）。 */
class LocalFs(private val root: File) : ModFs {

    override val label: String = root.name

    override fun list(): List<String> = root.walkTopDown()
        .filter { it.isFile }
        .map { it.relativeTo(root).invariantSeparatorsPath }
        .toList()

    override fun exists(path: String): Boolean = fileOf(path).isFile

    override fun readText(path: String, charset: Charset): String? =
        runCatching { fileOf(path).readText(charset) }.getOrNull()

    override fun writeText(path: String, text: String, charset: Charset): Boolean =
        runCatching { fileOf(path).writeText(text, charset) }.isSuccess

    override fun read(path: String): ByteArray? =
        runCatching { fileOf(path).readBytes() }.getOrNull()

    override fun write(path: String, bytes: ByteArray, mime: String): Boolean = runCatching {
        val f = fileOf(path)
        f.parentFile?.mkdirs()
        f.writeBytes(bytes)
        true
    }.getOrDefault(false)

    override fun delete(path: String): Boolean = runCatching { fileOf(path).delete() }.getOrDefault(false)

    override fun rename(from: String, to: String): Boolean = runCatching {
        val src = fileOf(from)
        val dst = fileOf(to)
        dst.parentFile?.mkdirs()
        src.renameTo(dst)
    }.getOrDefault(false)

    override fun localRoot(): File = root

    private fun fileOf(path: String): File = File(root, path.replace('/', File.separatorChar))
}

/**
 * SAF 实现：直接读写用户授权的原文件夹。
 * 首次构建文件索引，写操作后置脏，下次访问重建。
 */
class SafFs(
    private val context: Context,
    private val root: DocumentFile,
) : ModFs {

    override val label: String = root.name.orEmpty()

    private var index: MutableMap<String, DocumentFile> = LinkedHashMap()
    private var dirty = true

    private fun ensureIndex() {
        if (!dirty) return
        index = LinkedHashMap()
        walk(root, "")
        dirty = false
    }

    private fun walk(dir: DocumentFile, prefix: String) {
        dir.listFiles().forEach { child ->
            val name = child.name ?: return@forEach
            val path = if (prefix.isEmpty()) name else "$prefix/$name"
            if (child.isDirectory) walk(child, path) else index[path] = child
        }
    }

    override fun list(): List<String> {
        ensureIndex()
        return index.keys.toList()
    }

    override fun exists(path: String): Boolean {
        ensureIndex()
        return index.containsKey(path)
    }

    override fun readText(path: String, charset: Charset): String? =
        read(path)?.toString(charset)

    override fun writeText(path: String, text: String, charset: Charset): Boolean =
        write(path, text.toByteArray(charset), mimeFor(path))

    override fun read(path: String): ByteArray? = runCatching {
        ensureIndex()
        val doc = index[path] ?: return null
        context.contentResolver.openInputStream(doc.uri)?.use { it.readBytes() }
    }.getOrNull()

    override fun write(path: String, bytes: ByteArray, mime: String): Boolean = runCatching {
        ensureIndex()
        val existing = index[path]
        if (existing != null && existing.isFile) {
            context.contentResolver.openOutputStream(existing.uri, "wt")?.use { it.write(bytes) }
            return true
        }
        val parent = parentDir(path) ?: return false
        val name = path.substringAfterLast('/')
        val created = parent.createFile(mime, name) ?: return false
        // 少数 SAF 提供方会按 mime 追加扩展名，这里纠正回原文件名
        if (!created.name.equals(name, true)) {
            runCatching { created.renameTo(name) }
        }
        context.contentResolver.openOutputStream(created.uri, "wt")?.use { it.write(bytes) }
        index[path] = created
        true
    }.getOrDefault(false)

    override fun delete(path: String): Boolean = runCatching {
        ensureIndex()
        val doc = index[path] ?: return false
        val ok = doc.delete()
        if (ok) index.remove(path)
        ok
    }.getOrDefault(false)

    override fun rename(from: String, to: String): Boolean = runCatching {
        ensureIndex()
        val doc = index[from] ?: return false
        val newName = to.substringAfterLast('/')
        val ok = doc.renameTo(newName)
        if (ok) {
            index.remove(from)
            index[to] = doc
            dirty = true // document id 变了，重建索引
        }
        ok
    }.getOrDefault(false)

    /** 取（必要时创建）指定相对路径的目录。 */
    private fun parentDir(path: String): DocumentFile? {
        val parentPath = path.substringBeforeLast('/', "")
        if (parentPath.isEmpty()) return root
        var dir = root
        parentPath.split('/').forEach { segment ->
            if (segment.isEmpty()) return@forEach
            val child = dir.findFile(segment)
            dir = if (child != null && child.isDirectory) {
                child
            } else {
                dir.createDirectory(segment) ?: return null
            }
        }
        return dir
    }

    private fun mimeFor(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "xml", "i3d", "lua", "txt", "md", "csv" -> "text/plain"
        "dds" -> "image/vnd-ms.dds"
        else -> "application/octet-stream"
    }
}
