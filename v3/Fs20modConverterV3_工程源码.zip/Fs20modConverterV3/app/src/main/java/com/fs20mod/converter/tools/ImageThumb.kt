package com.fs20mod.converter.tools

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.fs20mod.converter.codec.DdsCodec
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Base64

/**
 * 缩略图编码：dds 交给 DdsCodec，png/jpg 先缩放再压成 PNG，
 * 避免把整张大图塞进桥接 JSON 拖慢页面。
 */
object ImageThumb {

    fun dataUrl(file: File, maxSide: Int = 384): String? {
        if (file.extension.equals("dds", true)) return DdsCodec.toDataUrl(file, maxSide)
        return runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0) return null

            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
            val decoded = BitmapFactory.decodeFile(
                file.absolutePath,
                BitmapFactory.Options().apply { inSampleSize = sample }
            ) ?: return null

            val longSide = maxOf(decoded.width, decoded.height)
            val scaled = if (longSide <= maxSide) decoded else {
                val ratio = maxSide.toFloat() / longSide
                Bitmap.createScaledBitmap(
                    decoded,
                    (decoded.width * ratio).toInt().coerceAtLeast(1),
                    (decoded.height * ratio).toInt().coerceAtLeast(1),
                    true
                )
            }
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.PNG, 100, out)
            if (scaled !== decoded) scaled.recycle()
            "data:image/png;base64," + Base64.getEncoder().encodeToString(out.toByteArray())
        }.getOrNull()
    }
}
