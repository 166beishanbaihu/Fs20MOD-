package com.fs20mod.converter.tools

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.fs20mod.converter.codec.DdsCodec
import com.fs20mod.converter.storage.ModFs
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Base64

/**
 * 缩略图编码：按原始比例缩到框内再压成 PNG，
 * 支持本地文件与 SAF 字节流两种来源，避免把整张大图塞进桥接 JSON。
 */
object ImageThumb {

    fun dataUrl(file: File, maxSide: Int = 384): String? {
        if (file.extension.equals("dds", true)) return DdsCodec.toDataUrl(file, maxSide)
        return runCatching { dataUrlBytes(file.readBytes(), file.extension, maxSide) }.getOrNull()
    }

    /** 从文件系统抽象读取：DDS 走解码器，其余走 BitmapFactory。 */
    fun dataUrl(fs: ModFs, path: String, maxSide: Int = 384): String? {
        val bytes = fs.read(path) ?: return null
        val ext = path.substringAfterLast('.', "").lowercase()
        if (ext == "dds") return DdsCodec.toDataUrl(bytes, maxSide)
        return dataUrlBytes(bytes, ext, maxSide)
    }

    fun dataUrlBytes(bytes: ByteArray, ext: String = "png", maxSide: Int = 384): String? = runCatching {
        if (ext.equals("dds", true)) return DdsCodec.toDataUrl(bytes, maxSide)

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0) return null

        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
        val decoded = BitmapFactory.decodeByteArray(
            bytes, 0, bytes.size,
            BitmapFactory.Options().apply { inSampleSize = sample }
        ) ?: return null

        val longSide = maxOf(decoded.width, decoded.height)
        val scaled = if (longSide <= maxSide) decoded else {
            val ratio = maxSide.toFloat() / longSide
            Bitmap.createScaledBitmap(
                decoded,
                (decoded.width * ratio).toInt().coerceAtLeast(1),
                (decoded.height * ratio).toInt().coerceAtLeast(1),
                true
            )
        }
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.PNG, 100, out)
        if (scaled !== decoded) scaled.recycle()
        "data:image/png;base64," + Base64.getEncoder().encodeToString(out.toByteArray())
    }.getOrNull()
}
