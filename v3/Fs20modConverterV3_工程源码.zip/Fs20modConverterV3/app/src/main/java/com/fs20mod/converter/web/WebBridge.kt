package com.fs20mod.converter.web

import android.content.Context
import android.net.Uri
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.documentfile.provider.DocumentFile
import com.fs20mod.converter.archive.Archive
import com.fs20mod.converter.debug.RunLog
import com.fs20mod.converter.domain.ConvertConfig
import com.fs20mod.converter.domain.Level
import com.fs20mod.converter.domain.Phase
import com.fs20mod.converter.mod.ModReader
import com.fs20mod.converter.mod.ModInfo
import com.fs20mod.converter.pipeline.ConversionPipeline
import com.fs20mod.converter.storage.ModFs
import com.fs20mod.converter.storage.SafFs
import com.fs20mod.converter.storage.SafStore
import com.fs20mod.converter.tools.Json
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 原生与网页之间的桥。 */
class WebBridge(
    private val context: Context,
    private val webView: WebView,
    private val host: Host,
) {

    interface Host {
        fun requestFolder()
        fun requestArchive()
        fun requestExport()
        fun requestLogExport()
        fun openExternal(url: String)
    }

    private val saf = SafStore(context)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val stamps = SimpleDateFormat("HH:mm:ss", Locale.US)

    /** 压缩包模式解压出的本地根目录 */
    @Volatile
    private var modRoot: File? = null

    /** 文件夹模式直接挂在 SAF 原文件夹上（就地覆盖） */
    @Volatile
    private var modFs: ModFs? = null

    @Volatile
    private var lastZip: File? = null

    @Volatile
    private var modInfo: ModInfo? = null

    // ---- JS 调用的入口 ----

    @JavascriptInterface
    fun version(): String {
        RunLog.step("BRIDGE", "version()")
        return com.fs20mod.converter.BuildConfig.VERSION_NAME
    }

    @JavascriptInterface
    fun pickFolder() {
        RunLog.step("BRIDGE", "pickFolder()")
        host.requestFolder()
    }

    @JavascriptInterface
    fun pickArchive() {
        RunLog.step("BRIDGE", "pickArchive()")
        host.requestArchive()
    }

    @JavascriptInterface
    fun exportResult() {
        RunLog.step("BRIDGE", "exportResult()")
        if (lastZip == null) {
            emit("window.App.onExport(${Json.obj("ok" to false, "msg" to "还没有转换结果")})")
        } else {
            host.requestExport()
        }
    }

    @JavascriptInterface
    fun openRepo(url: String) {
        RunLog.step("BRIDGE", "openRepo($url)")
        host.openExternal(url)
    }

    /** 界面读取最近运行日志。 */
    @JavascriptInterface
    fun logTail(lines: Int): String = RunLog.tail(lines)

    /** 导出运行日志到用户选择的位置。 */
    @JavascriptInterface
    fun exportLog() {
        RunLog.step("BRIDGE", "exportLog()")
        host.requestLogExport()
    }

    /** 最近一次崩溃报告，没有则返回空串。 */
    @JavascriptInterface
    fun lastCrash(): String = RunLog.lastCrash(context) ?: ""

    @JavascriptInterface
    fun clearCrash() {
        RunLog.clearCrash(context)
    }

    @JavascriptInterface
    fun startConvert(configJson: String) {
        val fs = modFs
        val root = modRoot
        if (fs == null && root == null) {
            emit("window.App.onDone(${Json.obj("ok" to false, "msg" to "还没有选择 mod")})")
            return
        }
        val config = parseConfig(configJson)
        val target = if (fs is SafFs) "原位 ${fs.label}" else root?.absolutePath.orEmpty()
        RunLog.step("CONVERT", "startConvert target=$target config=$configJson")
        log(Level.INFO, "开始转换")

        scope.launch {
            val pipeline = ConversionPipeline(
                config = config,
                log = { level, msg -> log(level, msg) },
                progress = { phase, ratio, note -> progress(phase, ratio, note) }
            )

            if (fs is SafFs) {
                // 文件夹模式：直接改写用户选中的原文件夹
                val result = runCatching { pipeline.runInPlace(fs) }
                    .onFailure { RunLog.e("CONVERT", "就地转换异常", it) }
                    .getOrElse {
                        emit("window.App.onDone(${Json.obj("ok" to false, "msg" to "转换异常，请查看日志")})")
                        return@launch
                    }
                RunLog.step("CONVERT", "就地完成 root=${fs.label} warnings=${result.warnings.size}")
                lastZip = null
                emit(
                    "window.App.onDone(" + Json.obj(
                        "ok" to true,
                        "name" to fs.label,
                        "inPlace" to true,
                        "msg" to "已就地转换，原文件夹已更新",
                        "details" to (result.details + ("模式" to "就地覆盖原文件夹")),
                        "warnings" to result.warnings.take(8),
                    ) + ")"
                )
                progress(Phase.FINISHED, 1f, "完成")
                return@launch
            }

            if (root == null) {
                emit("window.App.onDone(${Json.obj("ok" to false, "msg" to "还没有选择 mod")})")
                return@launch
            }
            val workDir = File(context.cacheDir, "convert/${System.currentTimeMillis()}")
            val name = config.outputName.ifBlank { root.name.ifBlank { "fs20mod" } } + "_fs20"
            val zip = File(workDir, "$name.zip")

            val result = runCatching { pipeline.run(root, workDir, zip) }
                .onFailure { RunLog.e("CONVERT", "管线异常", it) }
                .getOrElse {
                    emit("window.App.onDone(${Json.obj("ok" to false, "msg" to "转换异常，请查看日志")})")
                    return@launch
                }
            RunLog.step("CONVERT", "完成 zip=${result.zip?.absolutePath} warnings=${result.warnings.size}")
            lastZip = result.zip

            emit(
                "window.App.onDone(" + Json.obj(
                    "ok" to (result.zip != null),
                    "name" to "$name.zip",
                    "msg" to if (result.zip != null) "转换完成" else "转换失败，请查看日志",
                    "details" to result.details,
                    "warnings" to result.warnings.take(8),
                ) + ")"
            )
            progress(Phase.FINISHED, 1f, "完成")
        }
    }

    // ---- 由 Activity 回调 ----

    fun onFolderPicked(uri: Uri) {
        RunLog.step("SAF", "文件夹 uri=$uri")
        scope.launch {
          try {
            emit("window.App.onBusy(${Json.obj("msg" to "正在读取文件夹…")})")
            val tree = saf.tree(uri) ?: return@launch alsoEmitError("无法访问文件夹")
            // 就地模式：不复制到缓存，直接挂载原文件夹
            val fs = resolveModRoot(tree)
            RunLog.step("SAF", "就地挂载 ${fs.label}，共 ${fs.list().size} 个文件")
            val info = ModReader.inspect(context, fs)
            if (info == null) {
                alsoEmitError("这个文件夹里没有找到 modDesc.xml")
                return@launch
            }
            modFs = fs
            modRoot = null
            modInfo = info
            log(Level.INFO, "读取 ${fs.list().size} 个文件，识别为 ${info.gameLabel}")
            emit("window.App.onMod(${modJson(info)})")
          } catch (t: Throwable) {
            RunLog.e("SAF", "读取文件夹失败", t)
            alsoEmitError("读取失败：${t.message}")
          }
        }
    }

    fun onArchivePicked(uri: Uri) {
        RunLog.step("SAF", "压缩包 uri=$uri")
        scope.launch {
          try {
            emit("window.App.onBusy(${Json.obj("msg" to "正在解压…")})")
            val single = saf.file(uri) ?: return@launch alsoEmitError("无法访问压缩包")
            val stamp = System.currentTimeMillis()
            val local = File(context.cacheDir, "input/$stamp.zip")
            if (!saf.copyFile(single, local)) return@launch alsoEmitError("压缩包复制失败")
            val dir = File(context.cacheDir, "input/$stamp")
            RunLog.step("SAF", "解压 → ${dir.absolutePath}")
            Archive.unpack(local, dir)
            val root = Archive.modRoot(dir)
            RunLog.step("SAF", "mod 根目录 ${root.absolutePath}")
            val info = ModReader.inspect(context, root)
            if (info == null) {
                alsoEmitError("压缩包里没有找到 modDesc.xml")
                return@launch
            }
            modFs = null
            modRoot = root
            modInfo = info
            emit("window.App.onMod(${modJson(info)})")
          } catch (t: Throwable) {
            RunLog.e("SAF", "解压失败", t)
            alsoEmitError("解压失败：${t.message}")
          }
        }
    }

    fun onExportPicked(uri: Uri) {
        val zip = lastZip ?: return
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                val tree = saf.tree(uri)
                if (tree == null) false else saf.writeInto(tree, zip)
            }
            RunLog.step("EXPORT", "导出 ${zip.name} ok=$ok")
            emit("window.App.onExport(${Json.obj("ok" to ok, "msg" to if (ok) "已导出 ${zip.name}" else "导出失败")})")
        }
    }

    // ---- 内部 ----

    /**
     * 用户可能选中 mod 的父目录，这里向下收窄到真正含 modDesc.xml 的那一层，
     * 避免重命名/写入落在外层目录。
     */
    private fun resolveModRoot(tree: DocumentFile): SafFs {
        val top = SafFs(context, tree)
        val names = top.list()
        if (names.any { it == "modDesc.xml" }) return top

        val modDescPath = names.firstOrNull { it.substringAfterLast('/').equals("modDesc.xml", true) }
            ?: return top
        var dir: DocumentFile? = tree
        modDescPath.substringBeforeLast('/', "").split('/').forEach { segment ->
            if (segment.isEmpty() || dir == null) return@forEach
            dir = dir?.findFile(segment)
        }
        return dir?.let { SafFs(context, it) } ?: top
    }

    private fun parseConfig(json: String): ConvertConfig {
        fun flag(key: String, default: Boolean): Boolean {
            val m = Regex("\"$key\"\\s*:\\s*(true|false)").find(json) ?: return default
            return m.groupValues[1] == "true"
        }
        fun str(key: String): String =
            Regex("\"$key\"\\s*:\\s*\"([^\"]*)\"").find(json)?.groupValues?.get(1).orEmpty()

        return ConvertConfig(
            ddsToPng = flag("ddsToPng", true),
            renameVehicles = flag("renameVehicles", true),
            rewriteTitle = flag("rewriteTitle", true),
            syncI3d = flag("syncI3d", true),
            keepOriginals = flag("keepOriginals", false),
            outputName = str("outputName"),
        )
    }

    private fun modJson(info: ModInfo): String {
        val vehicles = info.vehicles.joinToString(",") { v ->
            Json.obj(
                "xmlName" to v.xmlName,
                "type" to v.type,
                "imageRef" to v.imageRef.orEmpty(),
                "imageUrl" to v.imageUrl.orEmpty(),
                "price" to v.price,
                "brand" to v.brand,
                "brandLogoUrl" to v.brandLogoUrl.orEmpty(),
                "i3dRef" to v.i3dRef.orEmpty(),
                "i3dExists" to v.i3dExists,
                "ddsRefs" to v.ddsRefs,
                "skippedRefs" to v.skippedRefs,
            )
        }
        return Json.obj(
            "rootName" to info.rootName,
            "descVersion" to info.descVersion,
            "gameLabel" to info.gameLabel,
            "modVersion" to info.modVersion,
            "title" to info.title,
            "vehicles" to Json.raw("[$vehicles]"),
        )
    }

    private fun log(level: Level, message: String) {
        when (level) {
            Level.ERROR -> RunLog.e("PIPE", message)
            Level.WARN -> RunLog.w("PIPE", message)
            else -> RunLog.i("PIPE", message)
        }
        val payload = Json.obj(
            "time" to stamps.format(Date()),
            "level" to level.name.lowercase(),
            "msg" to message,
        )
        emit("window.App.onLog($payload)")
    }

    private fun progress(phase: Phase, ratio: Float, note: String) {
        emit(
            "window.App.onProgress(" + Json.obj(
                "phase" to phase.title,
                "ratio" to (ratio * 100).toInt(),
                "note" to note,
            ) + ")"
        )
    }

    private fun alsoEmitError(message: String) {
        log(Level.ERROR, message)
        emit("window.App.onError(${Json.obj("msg" to message)})")
    }

    private fun emit(js: String) {
        webView.post { webView.evaluateJavascript("try{$js}catch(e){console.log(e)}", null) }
    }
}
