package com.fs20mod.converter.web

import android.content.Context
import android.net.Uri
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.documentfile.provider.DocumentFile
import com.fs20mod.converter.archive.Archive
import com.fs20mod.converter.domain.ConvertConfig
import com.fs20mod.converter.domain.Level
import com.fs20mod.converter.domain.Phase
import com.fs20mod.converter.mod.ModReader
import com.fs20mod.converter.mod.ModInfo
import com.fs20mod.converter.pipeline.ConversionPipeline
import com.fs20mod.converter.storage.SafStore
import com.fs20mod.converter.tools.Json
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 原生与网页之间的桥。 */
class WebBridge(
    private val context: Context,
    private val webView: WebView,
    private val host: Host,
) {

    interface Host {
        fun requestFolder()
        fun requestArchive()
        fun requestExport()
        fun openExternal(url: String)
    }

    private val saf = SafStore(context)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val stamps = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Volatile
    private var modRoot: File? = null

    @Volatile
    private var lastZip: File? = null

    @Volatile
    private var modInfo: ModInfo? = null

    // ---- JS 调用的入口 ----

    @JavascriptInterface
    fun version(): String = com.fs20mod.converter.BuildConfig.VERSION_NAME

    @JavascriptInterface
    fun pickFolder() = host.requestFolder()

    @JavascriptInterface
    fun pickArchive() = host.requestArchive()

    @JavascriptInterface
    fun exportResult() {
        if (lastZip == null) {
            emit("window.App.onExport(${Json.obj("ok" to false, "msg" to "还没有转换结果")})")
        } else {
            host.requestExport()
        }
    }

    @JavascriptInterface
    fun openRepo(url: String) = host.openExternal(url)

    @JavascriptInterface
    fun startConvert(configJson: String) {
        val root = modRoot
        if (root == null) {
            emit("window.App.onDone(${Json.obj("ok" to false, "msg" to "还没有选择 mod")})")
            return
        }
        val config = parseConfig(configJson)
        log(Level.INFO, "开始转换")

        scope.launch {
            val workDir = File(context.cacheDir, "convert/${System.currentTimeMillis()}")
            val name = config.outputName.ifBlank { root.name.ifBlank { "fs20mod" } } + "_fs20"
            val zip = File(workDir, "$name.zip")

            val pipeline = ConversionPipeline(
                config = config,
                log = { level, msg -> log(level, msg) },
                progress = { phase, ratio, note -> progress(phase, ratio, note) }
            )
            val result = pipeline.run(root, workDir, zip)
            lastZip = result.zip

            emit(
                "window.App.onDone(" + Json.obj(
                    "ok" to (result.zip != null),
                    "name" to "$name.zip",
                    "msg" to if (result.zip != null) "转换完成" else "转换失败，请查看日志",
                    "details" to result.details,
                    "warnings" to result.warnings.take(8),
                ) + ")"
            )
            progress(Phase.FINISHED, 1f, "完成")
        }
    }

    // ---- 由 Activity 回调 ----

    fun onFolderPicked(uri: Uri) {
        scope.launch {
            emit("window.App.onBusy(${Json.obj("msg" to "正在读取文件夹…")})")
            val tree = saf.tree(uri) ?: return@launch alsoEmitError("无法访问文件夹")
            val dir = File(context.cacheDir, "input/${System.currentTimeMillis()}")
            val count = saf.copyTree(tree, dir)
            val root = Archive.modRoot(dir)
            val info = ModReader.inspect(context, root)
            if (info == null) {
                alsoEmitError("这个文件夹里没有找到 modDesc.xml")
                return@launch
            }
            modRoot = root
            modInfo = info
            log(Level.INFO, "读取 ${count} 个文件，识别为 ${info.gameLabel}")
            emit("window.App.onMod(${modJson(info)})")
        }
    }

    fun onArchivePicked(uri: Uri) {
        scope.launch {
            emit("window.App.onBusy(${Json.obj("msg" to "正在解压…")})")
            val single = saf.file(uri) ?: return@launch alsoEmitError("无法访问压缩包")
            val stamp = System.currentTimeMillis()
            val local = File(context.cacheDir, "input/$stamp.zip")
            if (!saf.copyFile(single, local)) return@launch alsoEmitError("压缩包复制失败")
            val dir = File(context.cacheDir, "input/$stamp")
            Archive.unpack(local, dir)
            val root = Archive.modRoot(dir)
            val info = ModReader.inspect(context, root)
            if (info == null) {
                alsoEmitError("压缩包里没有找到 modDesc.xml")
                return@launch
            }
            modRoot = root
            modInfo = info
            emit("window.App.onMod(${modJson(info)})")
        }
    }

    fun onExportPicked(uri: Uri) {
        val zip = lastZip ?: return
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                val tree = saf.tree(uri)
                if (tree == null) false else saf.writeInto(tree, zip)
            }
            emit("window.App.onExport(${Json.obj("ok" to ok, "msg" to if (ok) "已导出 ${zip.name}" else "导出失败")})")
        }
    }

    // ---- 内部 ----

    private fun parseConfig(json: String): ConvertConfig {
        fun flag(key: String, default: Boolean): Boolean {
            val m = Regex("\"$key\"\\s*:\\s*(true|false)").find(json) ?: return default
            return m.groupValues[1] == "true"
        }
        fun str(key: String): String =
            Regex("\"$key\"\\s*:\\s*\"([^\"]*)\"").find(json)?.groupValues?.get(1).orEmpty()

        return ConvertConfig(
            ddsToPng = flag("ddsToPng", true),
            renameVehicles = flag("renameVehicles", true),
            rewriteTitle = flag("rewriteTitle", true),
            syncI3d = flag("syncI3d", true),
            keepOriginals = flag("keepOriginals", false),
            outputName = str("outputName"),
        )
    }

    private fun modJson(info: ModInfo): String {
        val vehicles = info.vehicles.joinToString(",") { v ->
            Json.obj(
                "xmlName" to v.xmlName,
                "type" to v.type,
                "imageRef" to v.imageRef.orEmpty(),
                "imageUrl" to v.imageUrl.orEmpty(),
                "price" to v.price,
                "brand" to v.brand,
                "brandLogoUrl" to v.brandLogoUrl.orEmpty(),
                "i3dRef" to v.i3dRef.orEmpty(),
                "i3dExists" to v.i3dExists,
                "ddsRefs" to v.ddsRefs,
                "skippedRefs" to v.skippedRefs,
            )
        }
        return Json.obj(
            "rootName" to info.rootName,
            "descVersion" to info.descVersion,
            "gameLabel" to info.gameLabel,
            "modVersion" to info.modVersion,
            "title" to info.title,
            "vehicles" to "[$vehicles]",
        )
    }

    private fun log(level: Level, message: String) {
        val payload = Json.obj(
            "time" to stamps.format(Date()),
            "level" to level.name.lowercase(),
            "msg" to message,
        )
        emit("window.App.onLog($payload)")
    }

    private fun progress(phase: Phase, ratio: Float, note: String) {
        emit(
            "window.App.onProgress(" + Json.obj(
                "phase" to phase.title,
                "ratio" to (ratio * 100).toInt(),
                "note" to note,
            ) + ")"
        )
    }

    private fun alsoEmitError(message: String) {
        log(Level.ERROR, message)
        emit("window.App.onError(${Json.obj("msg" to message)})")
    }

    private fun emit(js: String) {
        webView.post { webView.evaluateJavascript("try{$js}catch(e){console.log(e)}", null) }
    }
}
