package com.fs20mod.converter.pipeline

import com.fs20mod.converter.archive.Archive
import com.fs20mod.converter.codec.DdsCodec
import com.fs20mod.converter.domain.ConvertConfig
import com.fs20mod.converter.domain.Level
import com.fs20mod.converter.domain.PassReport
import com.fs20mod.converter.domain.Phase
import com.fs20mod.converter.tools.XmlKit
import org.w3c.dom.Element
import java.io.File

/** 贴图：DDS → PNG，删除原文件（可选保留备份）。 */
internal class TexturePass(
    private val root: File,
    private val config: ConvertConfig,
    private val log: (Level, String) -> Unit,
    private val tick: (Float, String) -> Unit,
) {
    fun execute(): PassReport {
        val files = root.walkTopDown().filter { it.isFile && it.extension.equals("dds", true) }.toList()
        log(Level.INFO, "发现 DDS ${files.size} 个")
        var done = 0
        var failed = 0
        val failures = mutableListOf<String>()

        files.forEachIndexed { i, dds ->
            val png = File(dds.parentFile, dds.nameWithoutExtension + ".png")
            if (config.keepOriginals) {
                runCatching { dds.copyTo(File(dds.absolutePath + ".bak"), overwrite = true) }
            }
            if (DdsCodec.toPng(dds, png)) {
                done++
                if (!config.keepOriginals) runCatching { dds.delete() }
                log(Level.INFO, "DDS → PNG：${dds.name}")
            } else {
                failed++
                failures += "贴图失败：${dds.relativeTo(root).path}"
                log(Level.WARN, "解码失败，保留原文件：${dds.name}")
            }
            tick((i + 1).toFloat() / files.size.coerceAtLeast(1), "贴图 ${i + 1}/${files.size}")
        }

        return PassReport(
            "贴图转换",
            details = mapOf("转换成功" to "$done 张", "转换失败" to "$failed 张"),
            warnings = failures,
        )
    }
}

/** storeItems：车辆 XML 重命名到 520.xml 起，同步 modDesc 引用与标题前缀。 */
internal class StoreItemPass(
    private val root: File,
    private val config: ConvertConfig,
    private val log: (Level, String) -> Unit,
) {
    var renameMap: Map<String, String> = emptyMap()
        private set

    fun execute(): PassReport {
        val modDesc = root.walkTopDown().firstOrNull { it.isFile && it.name.equals("modDesc.xml", true) }
            ?: return PassReport("商店条目", warnings = listOf("未找到 modDesc.xml"))
        val doc = XmlKit.parse(modDesc)
            ?: return PassReport("商店条目", warnings = listOf("modDesc.xml 解析失败"))

        val items = doc.getElementsByTagName("storeItem")
        val files = LinkedHashSet<File>()
        for (i in 0 until items.length) {
            val attr = items.item(i).attributes?.getNamedItem("xmlFilename") ?: continue
            val ref = attr.nodeValue.replace('\\', '/')
            val name = ref.substringAfterLast('/')
            root.walkTopDown().firstOrNull { it.isFile && it.name.equals(name, true) }?.let { files += it }
        }
        log(Level.INFO, "storeItems 引用车辆 ${files.size} 个")

        val map = LinkedHashMap<String, String>()
        var index = 520
        files.forEach { file ->
            while (File(file.parentFile, "$index.xml").exists()) index++
            val target = File(file.parentFile, "$index.xml")
            if (!file.name.equals(target.name, true) && file.renameTo(target)) {
                map[file.name] = target.name
                log(Level.INFO, "重命名 ${file.name} → ${target.name}")
            }
            index++
        }

        for (i in 0 until items.length) {
            val attr = items.item(i).attributes?.getNamedItem("xmlFilename") ?: continue
            val ref = attr.nodeValue.replace('\\', '/')
            val name = ref.substringAfterLast('/')
            val renamed = map.entries.firstOrNull { it.key.equals(name, true) }?.value ?: continue
            val prefix = ref.substringBeforeLast('/', "")
            attr.nodeValue = if (prefix.isEmpty()) renamed else "$prefix/$renamed"
        }

        var titleChanged = false
        if (config.rewriteTitle) {
            val titles = doc.getElementsByTagName("title")
            for (i in 0 until titles.length) {
                val el = titles.item(i) as? Element ?: continue
                val en = el.getElementsByTagName("en").item(0) as? Element ?: continue
                val old = en.textContent.trim()
                if (old.isEmpty() || old.startsWith("FS20_")) continue
                en.textContent = "FS20_" + old.substringAfter(' ', old)
                titleChanged = true
            }
        }

        if (map.isNotEmpty() || titleChanged) XmlKit.write(doc, modDesc)
        renameMap = map

        return PassReport(
            "商店条目",
            details = mapOf(
                "重命名" to "${map.size} 个", "标题改写" to if (titleChanged) "已改写" else "未改动"
            ),
        )
    }
}

/** I3D：Files 引用里 .dds → .png（$ 开头行跳过），文件内 dds 全改 png，同步 XML 重命名与 shader 版本。 */
internal class I3dPass(
    private val root: File,
    private val renameMap: Map<String, String>,
    private val log: (Level, String) -> Unit,
    private val tick: (Float, String) -> Unit,
) {
    fun execute(): PassReport {
        val files = root.walkTopDown().filter { it.isFile && it.extension.equals("i3d", true) }.toList()
        log(Level.INFO, "处理 I3D ${files.size} 个")
        var touched = 0
        var patches = 0
        var refs = 0

        files.forEachIndexed { i, i3d ->
            val lines = XmlKit.replaceTextLines(i3d) { line ->
                // 以 $ 开头的资源引用整行跳过
                if (line.contains("filename=\"$")) return@replaceTextLines line
                line.replace(Regex("(\\.dds)(?![A-Za-z0-9])", RegexOption.IGNORE_CASE), ".png")
            }
            if (lines > 0) {
                touched++
                refs += lines
                log(Level.INFO, "${i3d.name}：$lines 行贴图引用改写")
            }

            // 同步被引用 XML 的重命名与 CustomShader 版本
            val text = runCatching { i3d.readText(Charsets.ISO_8859_1) }.getOrNull()
            if (text != null) {
                Regex("""filename\s*=\s*"([^"]*)"""").findAll(text).forEach { m ->
                    val value = m.groupValues[1]
                    if (value.contains(".xml", true)) {
                        val base = value.substringAfterLast('/')
                        val renamed = renameMap.entries.firstOrNull { it.key.equals(base, true) }?.value
                        val xmlFile = File(i3d.parentFile, if (renamed != null) value.replace(base, renamed) else value)
                        val target = if (xmlFile.isFile) xmlFile
                        else root.walkTopDown().firstOrNull { it.isFile && it.name.equals(base, true) }
                        if (target != null && target.isFile) patches += patchShader(target)
                    }
                }
            }
            tick((i + 1).toFloat() / files.size.coerceAtLeast(1), "I3D ${i + 1}/${files.size}")
        }

        return PassReport(
            "I3D 同步",
            details = mapOf("改写文件" to "$touched 个", "贴图引用" to "$refs 处", "Shader 升级" to "$patches 处"),
        )
    }

    /** 只替换 CustomShader 的 version="4"，其余字节原样保留。 */
    private fun patchShader(file: File): Int {
        val text = runCatching { file.readText(Charsets.ISO_8859_1) }.getOrNull() ?: return 0
        var count = 0
        val updated = Regex("""(?i)(<CustomShader\b[^>]*?\bversion\s*=\s*["']4["'])""").replace(text) { m ->
            count++
            m.value.replace(Regex("""(?i)\bversion\s*=\s*["']4["']"""), "version=\"5\"")
        }
        if (count > 0) file.writeText(updated, Charsets.ISO_8859_1)
        return count
    }
}

/** 管线编排。 */
class ConversionPipeline(
    private val config: ConvertConfig,
    private val log: (Level, String) -> Unit,
    private val progress: (Phase, Float, String) -> Unit,
) {

    data class Result(
        val zip: File?,
        val details: Map<String, String>,
        val warnings: List<String>,
    )

    fun run(input: File, workDir: File, outputZip: File): Result {
        workDir.mkdirs()
        progress(Phase.PREPARE, 0.02f, "读取输入")
        val root = if (input.isDirectory) input else {
            val unzip = File(workDir, "unzip")
            log(Level.INFO, "解压 ${input.name}")
            val n = Archive.unpack(input, unzip)
            log(Level.INFO, "解压 $n 个文件")
            Archive.modRoot(unzip)
        }

        if (!File(root, "modDesc.xml").exists() &&
            root.walkTopDown().none { it.isFile && it.name.equals("modDesc.xml", true) }
        ) {
            log(Level.WARN, "未找到 modDesc.xml，可能不是标准 mod")
        }

        val warnings = mutableListOf<String>()
        val details = linkedMapOf<String, String>()

        // 1 贴图
        progress(Phase.TEXTURE, 0.05f, "转换贴图")
        if (config.ddsToPng) {
            val rep = TexturePass(root, config, log) { r, note ->
                progress(Phase.TEXTURE, 0.05f + 0.45f * r, note)
            }.execute()
            details.putAll(rep.details)
            warnings += rep.warnings
        }

        // 2 storeItems
        progress(Phase.STORE_ITEMS, 0.52f, "处理商店条目")
        val store = StoreItemPass(root, config, log)
        if (config.renameVehicles || config.rewriteTitle) {
            val rep = store.execute()
            details.putAll(rep.details)
            warnings += rep.warnings
        }

        // 3 i3d
        progress(Phase.I3D, 0.64f, "同步 I3D")
        if (config.syncI3d) {
            val rep = I3dPass(root, store.renameMap, log) { r, note ->
                progress(Phase.I3D, 0.64f + 0.26f * r, note)
            }.execute()
            details.putAll(rep.details)
            warnings += rep.warnings
        }

        // 4 打包
        progress(Phase.ARCHIVE, 0.92f, "打包")
        val ok = Archive.pack(root, outputZip) { count ->
            if (count % 50 == 0) progress(Phase.ARCHIVE, 0.92f, "已写入 $count 个文件")
        }
        if (!ok) {
            warnings += "打包失败"
            log(Level.ERROR, "打包 zip 失败")
        }

        progress(Phase.FINISHED, 1f, "完成")
        return Result(if (ok) outputZip else null, details, warnings)
    }
}
