package com.fs20mod.converter.pipeline

import com.fs20mod.converter.archive.Archive
import com.fs20mod.converter.codec.DdsCodec
import com.fs20mod.converter.debug.RunLog
import com.fs20mod.converter.domain.ConvertConfig
import com.fs20mod.converter.domain.Level
import com.fs20mod.converter.domain.PassReport
import com.fs20mod.converter.domain.Phase
import com.fs20mod.converter.mod.ModReader
import com.fs20mod.converter.storage.LocalFs
import com.fs20mod.converter.storage.ModFs
import com.fs20mod.converter.tools.XmlKit
import org.w3c.dom.Element
import java.io.File

/** 贴图：DDS → PNG 就地写入，删除原文件（可选保留 .bak 备份）。 */
internal class TexturePass(
    private val fs: ModFs,
    private val config: ConvertConfig,
    private val log: (Level, String) -> Unit,
    private val tick: (Float, String) -> Unit,
) {
    fun execute(): PassReport {
        val files = fs.list().filter { it.substringAfterLast('.', "").equals("dds", true) }
        log(Level.INFO, "发现 DDS ${files.size} 个")
        var done = 0
        var failed = 0
        val failures = mutableListOf<String>()

        files.forEachIndexed { i, ddsPath ->
            val ddsBytes = fs.read(ddsPath)
            if (ddsBytes == null) {
                failed++
                failures += "读取失败：$ddsPath"
                log(Level.WARN, "读取失败，跳过：$ddsPath")
            } else {
                val pngPath = ddsPath.substringBeforeLast('.') + ".png"
                val pngBytes = DdsCodec.toPngBytes(ddsBytes)
                if (pngBytes != null && fs.write(pngPath, pngBytes, "image/png")) {
                    done++
                    if (config.keepOriginals) {
                        fs.write(ddsPath + ".bak", ddsBytes, "application/octet-stream")
                    } else {
                        fs.delete(ddsPath)
                    }
                    log(Level.INFO, "DDS → PNG：${ddsPath.substringAfterLast('/')}")
                } else {
                    failed++
                    failures += "贴图失败：$ddsPath"
                    log(Level.WARN, "解码失败，保留原文件：${ddsPath.substringAfterLast('/')}")
                }
            }
            tick((i + 1).toFloat() / files.size.coerceAtLeast(1), "贴图 ${i + 1}/${files.size}")
        }

        return PassReport(
            "贴图转换",
            details = mapOf("转换成功" to "$done 张", "转换失败" to "$failed 张"),
            warnings = failures,
        )
    }
}

/** storeItems：车辆 XML 重命名到 520.xml 起，同步 modDesc 引用与标题前缀。 */
internal class StoreItemPass(
    private val fs: ModFs,
    private val config: ConvertConfig,
    private val log: (Level, String) -> Unit,
) {
    /** 旧文件名 → 新文件名 */
    var renameMap: Map<String, String> = emptyMap()
        private set

    fun execute(): PassReport {
        val modDescPath = fs.list().firstOrNull {
            it.substringAfterLast('/').equals("modDesc.xml", true)
        } ?: return PassReport("商店条目", warnings = listOf("未找到 modDesc.xml"))

        val text = fs.readText(modDescPath)
            ?: return PassReport("商店条目", warnings = listOf("modDesc.xml 读取失败"))
        val doc = XmlKit.parseText(text)
            ?: return PassReport("商店条目", warnings = listOf("modDesc.xml 解析失败"))

        val items = doc.getElementsByTagName("storeItem")
        val targets = LinkedHashSet<String>()
        for (i in 0 until items.length) {
            val attr = items.item(i).attributes?.getNamedItem("xmlFilename") ?: continue
            val ref = attr.nodeValue.replace('\\', '/')
            ModReader.locate(fs, ref)?.let { targets += it }
        }
        log(Level.INFO, "storeItems 引用车辆 ${targets.size} 个")

        val map = LinkedHashMap<String, String>()
        var index = 520
        targets.forEach { path ->
            val dir = path.substringBeforeLast('/', "")
            var newName = "$index.xml"
            while (fs.exists(if (dir.isEmpty()) newName else "$dir/$newName")) {
                index++
                newName = "$index.xml"
            }
            val oldName = path.substringAfterLast('/')
            val newPath = if (dir.isEmpty()) newName else "$dir/$newName"
            if (!oldName.equals(newName, true) && fs.rename(path, newPath)) {
                map[oldName] = newName
                log(Level.INFO, "重命名 $oldName → $newName")
            }
            index++
        }

        for (i in 0 until items.length) {
            val attr = items.item(i).attributes?.getNamedItem("xmlFilename") ?: continue
            val ref = attr.nodeValue.replace('\\', '/')
            val name = ref.substringAfterLast('/')
            val renamed = map.entries.firstOrNull { it.key.equals(name, true) }?.value ?: continue
            val prefix = ref.substringBeforeLast('/', "")
            attr.nodeValue = if (prefix.isEmpty()) renamed else "$prefix/$renamed"
        }

        val alreadyConverted = Regex("""<title>\s*<en>FS20_[^<]*</en>""").containsMatchIn(text)
        if (alreadyConverted) {
            log(Level.WARN, "modDesc 标题已带 FS20_ 前缀，这个 mod 可能已被转换过，再次转换会继续改名")
        }

        var titleChanged = false
        if (config.rewriteTitle) {
            val titles = doc.getElementsByTagName("title")
            for (i in 0 until titles.length) {
                val el = titles.item(i) as? Element ?: continue
                val en = el.getElementsByTagName("en").item(0) as? Element ?: continue
                val old = en.textContent.trim()
                if (old.isEmpty() || old.startsWith("FS20_")) continue
                en.textContent = "FS20_" + old.substringAfter(' ', old)
                titleChanged = true
            }
        }

        if (map.isNotEmpty() || titleChanged) {
            val out = XmlKit.toText(doc)
            if (out != null) fs.writeText(modDescPath, out) else log(Level.WARN, "modDesc 写回失败")
        }
        renameMap = map

        return PassReport(
            "商店条目",
            details = mapOf(
                "重命名" to "${map.size} 个",
                "标题改写" to if (titleChanged) "已改写" else "未改动",
            ),
        )
    }
}

/** 车辆 XML 里的封面引用：<image>store_JAC.dds</image> → .png */
internal class ImageRefPass(
    private val fs: ModFs,
    private val log: (Level, String) -> Unit,
) {
    private val imageTagRe = Regex("""(<image>\s*[^<]*?)\.dds(\s*</image>)""", RegexOption.IGNORE_CASE)

    fun execute(): PassReport {
        val xmls = fs.list().filter { it.substringAfterLast('.', "").equals("xml", true) }
        var touched = 0
        var refs = 0

        xmls.forEach { path ->
            val text = fs.readText(path) ?: return@forEach
            var count = 0
            val out = imageTagRe.replace(text) { m ->
                count++
                m.groupValues[1] + ".png" + m.groupValues[2]
            }
            if (count > 0 && fs.writeText(path, out)) {
                touched++
                refs += count
                log(Level.INFO, "封面引用 ${path.substringAfterLast('/')}：$count 处 .dds → .png")
            }
        }

        return PassReport(
            "封面引用",
            details = mapOf("改写文件" to "$touched 个", "封面路径" to "$refs 处"),
        )
    }
}

/** I3D：Files 引用里 .dds → .png（$ 开头行跳过），同步 XML 重命名与 CustomShader 版本。 */
internal class I3dPass(
    private val fs: ModFs,
    private val renameMap: Map<String, String>,
    private val log: (Level, String) -> Unit,
    private val tick: (Float, String) -> Unit,
) {
    fun execute(): PassReport {
        val files = fs.list().filter { it.substringAfterLast('.', "").equals("i3d", true) }
        log(Level.INFO, "处理 I3D ${files.size} 个")
        var touched = 0
        var patches = 0
        var refs = 0

        files.forEachIndexed { i, path ->
            val text = fs.readText(path, Charsets.ISO_8859_1)
            if (text == null) {
                log(Level.WARN, "读取失败：$path")
            } else {
                var changed = 0
                val out = text.lineSequence().joinToString("\n") { line ->
                    // 以 $ 开头的资源引用整行跳过
                    if (line.contains("filename=\"$")) return@joinToString line
                    val next = line.replace(Regex("(\\.dds)(?![A-Za-z0-9])", RegexOption.IGNORE_CASE), ".png")
                    if (next != line) changed++
                    next
                }
                if (changed > 0 && fs.writeText(path, out, Charsets.ISO_8859_1)) {
                    touched++
                    refs += changed
                    log(Level.INFO, "${path.substringAfterLast('/')}：$changed 行贴图引用改写")
                }

                // 同步被引用 XML 的重命名与 CustomShader 版本
                Regex("""filename\s*=\s*"([^"]*)"""").findAll(text).forEach { m ->
                    val value = m.groupValues[1]
                    if (!value.contains(".xml", true)) return@forEach
                    val base = value.substringAfterLast('/')
                    val renamed = renameMap.entries.firstOrNull { it.key.equals(base, true) }?.value
                    val refPath = if (renamed != null) value.replace(base, renamed) else value
                    val target = ModReader.locate(fs, refPath, from = path)
                    if (target != null) patches += patchShader(target)
                }
            }
            tick((i + 1).toFloat() / files.size.coerceAtLeast(1), "I3D ${i + 1}/${files.size}")
        }

        return PassReport(
            "I3D 同步",
            details = mapOf(
                "改写文件" to "$touched 个",
                "贴图引用" to "$refs 处",
                "Shader 升级" to "$patches 处",
            ),
        )
    }

    /** 只替换 CustomShader 的 version="4"，其余内容原样保留。 */
    private fun patchShader(path: String): Int {
        val text = fs.readText(path, Charsets.ISO_8859_1) ?: return 0
        var count = 0
        val updated = Regex("""(?i)(<CustomShader\b[^>]*?\bversion\s*=\s*["']4["'])""").replace(text) { m ->
            count++
            m.value.replace(Regex("""(?i)\bversion\s*=\s*["']4["']"""), "version=\"5\"")
        }
        if (count > 0) fs.writeText(path, updated, Charsets.ISO_8859_1)
        return count
    }
}

/** 管线编排：本地目录（压缩包模式）与 SAF 原文件夹（就地模式）共用同一套 pass。 */
class ConversionPipeline(
    private val config: ConvertConfig,
    private val log: (Level, String) -> Unit,
    private val progress: (Phase, Float, String) -> Unit,
) {

    data class Result(
        val zip: File?,
        val details: Map<String, String>,
        val warnings: List<String>,
        val inPlace: Boolean = false,
    )

    /** 压缩包模式：解压到工作目录，转换完打包成 zip。 */
    fun run(input: File, workDir: File, outputZip: File): Result {
        workDir.mkdirs()
        progress(Phase.PREPARE, 0.02f, "读取输入")
        val root = if (input.isDirectory) input else {
            val unzip = File(workDir, "unzip")
            log(Level.INFO, "解压 ${input.name}")
            val n = Archive.unpack(input, unzip)
            log(Level.INFO, "解压 $n 个文件")
            Archive.modRoot(unzip)
        }
        val fs = LocalFs(root)
        val result = transform(fs)

        progress(Phase.ARCHIVE, 0.92f, "打包")
        val ok = Archive.pack(root, outputZip) { count ->
            if (count % 50 == 0) progress(Phase.ARCHIVE, 0.92f, "已写入 $count 个文件")
        }
        var warnings = result.warnings
        if (!ok) {
            warnings = warnings + "打包失败"
            log(Level.ERROR, "打包 zip 失败")
        }
        progress(Phase.FINISHED, 1f, "完成")
        return Result(if (ok) outputZip else null, result.details, warnings)
    }

    /** 文件夹模式：直接在原文件夹上就地改写，不复制、不打包。 */
    fun runInPlace(fs: ModFs): Result {
        RunLog.step("PIPE", "就地转换开始（原文件夹）")
        progress(Phase.PREPARE, 0.02f, "读取输入")
        val result = transform(fs)
        progress(Phase.FINISHED, 1f, "完成")
        return result.copy(inPlace = true)
    }

    private fun transform(fs: ModFs): Result {
        if (!fs.list().any { it.substringAfterLast('/').equals("modDesc.xml", true) }) {
            log(Level.WARN, "未找到 modDesc.xml，可能不是标准 mod")
        }

        val warnings = mutableListOf<String>()
        val details = linkedMapOf<String, String>()

        // 1 贴图
        progress(Phase.TEXTURE, 0.05f, "转换贴图")
        if (config.ddsToPng) {
            val rep = TexturePass(fs, config, log) { r, note ->
                progress(Phase.TEXTURE, 0.05f + 0.45f * r, note)
            }.execute()
            details.putAll(rep.details)
            warnings += rep.warnings
        }

        // 2 storeItems
        progress(Phase.STORE_ITEMS, 0.52f, "处理商店条目")
        val store = StoreItemPass(fs, config, log)
        if (config.renameVehicles || config.rewriteTitle) {
            val rep = store.execute()
            details.putAll(rep.details)
            warnings += rep.warnings
        }

        // 2.5 车辆 XML 封面引用
        progress(Phase.STORE_ITEMS, 0.60f, "改写封面引用")
        val imageRep = ImageRefPass(fs, log).execute()
        details.putAll(imageRep.details)
        warnings += imageRep.warnings

        // 3 i3d
        progress(Phase.I3D, 0.64f, "同步 I3D")
        if (config.syncI3d) {
            val rep = I3dPass(fs, store.renameMap, log) { r, note ->
                progress(Phase.I3D, 0.64f + 0.26f * r, note)
            }.execute()
            details.putAll(rep.details)
            warnings += rep.warnings
        }

        return Result(null, details, warnings)
    }
}
